#pragma once
#pragma comment(lib, "ws2_32")
#include <Winsock2.h>
#include <Windows.h>
#include <iostream>
#include <mutex>
#include <vector>
#include <map>
#include <set>
#include <queue>
#include <thread>
#include <D3DX10math.h>


using namespace std;

#define SERVER_PORT	9000
#define SERVER_IP "127,0,0,1"

//#define SC_POS				1
//#define SC_PUT_PLAYER		2
//#define SC_REMOVE_PLAYER	3



#define CS_KEY				4

#define MAX_BUFFER_SIZE	4000
#define MAX_PACKET_SIZE 255

#define MAX_USER 10

#define OP_RECV 1
#define OP_SEND 2


const DWORD KEY_UP		= 0x00000000;
const DWORD KEY_DOWN	= 0x00000001;
const DWORD KEY_LEFT	= 0x00000002;
const DWORD KEY_RIGHT	= 0x00000004;

struct Overlap_ex
{
	WSAOVERLAPPED Original_Overlap;
	int operation_type;
	WSABUF wsabuf;
	unsigned char IOCPbuf[MAX_BUFFER_SIZE];
	unsigned char Packetbuf[MAX_PACKET_SIZE];
};

struct PLAYER_INFO
{
	D3DXVECTOR3 position;
	SOCKET sock;
	bool connected;
	unsigned int prev_received;
	unsigned int curr_paket_size;
	Overlap_ex my_overapped;

	CRITICAL_SECTION cs;
};
//////////////////////////////////////////


struct KEY_INPUT
{
	BYTE size;
	BYTE type;
	DWORD movetype;
};

struct PLAYER_POS
{
	BYTE size;
	BYTE type;
	int ID;
	D3DXVECTOR3 dir;
	D3DXVECTOR3 Position;
	unsigned int prev_received;
	unsigned int curr_paket_size;
	unsigned char Packetbuf[MAX_PACKET_SIZE];
};


struct Packet_remove_Player
{
	BYTE size;
	BYTE type;
	WORD id;
};

//////////////////////////////////////////
//Ŭ���̾�Ʈ��Ŷ����ü

struct Client
{
	SOCKET s;
	bool connected;
	PLAYER_POS PlayerPos;
	Overlap_ex recv_overlap;
	int packet_size;
	int previous_size;
	unsigned char packet_buff[MAX_PACKET_SIZE];
};
