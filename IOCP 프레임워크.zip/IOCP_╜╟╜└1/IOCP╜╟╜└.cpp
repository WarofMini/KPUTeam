#include "Server.h"

int main(void)
{
	_wsetlocale(LC_ALL, L"korean");

	CServer iocpserver;

	return 0;
}