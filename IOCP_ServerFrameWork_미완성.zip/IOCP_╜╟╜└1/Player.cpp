#include "Player.h"



CPlayer::CPlayer()
{
}


CPlayer::~CPlayer()
{
}
