#pragma once
#include "Protocol.h"
#include "Player.h"

class CServer
{

private:
	D3DXVECTOR3 vPosition;
	Client m_Client[MAX_USER];
	HANDLE g_hIocp;
	bool g_bShoutdown = false;
	DWORD KeyValue;
	CPlayer*	m_pPlayer;

public:
	void error_display(char *msg, int err_no);

	void Initialize(void);
	void SendPacket(int id, void *packet);
	void ProcessPacket(char *packet, int id);
	void Accept_thread();
	void Worker_thread();

public:
	CServer();
	~CServer();
};

